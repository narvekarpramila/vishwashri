<!DOCTYPE html>
<html lang="en">
<head>
  <title>Quotation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/style.css" rel="stylesheet" />
</head>
<body>
<div id="canvas_div_pdf">
  <div class="container square">
    <!-- <div class="table-responsive"> -->
    <table class="table">
      <tr style="">
        <td style="border:none !important;width: 20%;"><img src="logo2.png" class="logo mb-1"> </td>
        <td  style="border:none !important;width: 40%;">
          <span class="ml-4 mb-1 sm-font">
          <p><b>Office :</b> Savali Sadan, Vadgaon Road,<br> Vishrantvad,Alandi, Tal. Khed,<br> Pune - 412 105, Maharashtra </p>
          <p><b>Website :</b> www.vishwashripackers.in</p> 
        </span>
        </td>
         <td  style="border:none !important;width: 40%;">
          <span class="ml-4 mb-1">
           <p><b>Mob. :</b> 9921577116 / 9730577116 </p>
            <p><b>E-mail :</b> vishwashripackers@gmail.com</p>
          <p> <b>PAN No. :</b> BDSPP6209E</p> 
          <p> <b>GSTIN NO. :</b> 27BDSPP6209E1Z8</p>
          </span>
         </td>
        </tr>
      </table>
    <!-- </div> -->
      <table class="table table-bordered bordered" style="color: #000; font-weight:bold">
              <tr>
                <td class="tlw"> <label> Mr./ Mrs. : </label></td>
                <td class="lb"> <textarea name="name" rows="2" class="form-control"></textarea></td>                    
                <td class="rb tlw"> <label> Quotation No. :</label> </td>
                <td class="lb trw"><textarea rows="2" name="quotation_no" class="form-control"></textarea></td>
              </tr>
              <tr>
                <td colspan="2"> <textarea rows="2" name="name" class="form-control"></textarea></td>  
                <td class="rb"> <label> Date :</label> </td>
                <td class="lb"> <textarea rows="2" name="date" class="form-control"></textarea></td>  
              </tr>
              <tr>
                <td colspan="2"> <textarea rows="2" name="name" class="form-control"></textarea></td>  
                <td class="trw rb"> <label> From : </label></td>
                <td class="lb"> <textarea rows="2" name="name" class="form-control"></textarea></td>  
              </tr>
              <tr>
                <td class="rb"> <label> Mobile No. :</label></td>
                <td class="lb"> <textarea rows="2" name="name" class="form-control"></textarea></td>  
                <td class="trw rb"> <label> To : </label></td>
                <td class="lb"> <textarea rows="2" name="name" class="form-control"></textarea></td>  
              </tr>
            </table>

        <table class="table">
          <tr>
            <td style="border:none !important;color: #041144;"> <span class="mt-2 mb-2"><b style="border-bottom: 4px solid;font-size: 16px"> SUB : QUOTATION FOR PACKING AND MOVING </b> <br> <p class="mt-1">Dear Sir/Madam,
              We thank you for your enquiry for shifting of your household goods
              We are pleased to quote our lowest possible rates as follows:
            </p></span>
          </td>
        </tr>


      </table>
      <div class="row">
        <div class="col-md-3 col-xs-3">
           <table class="table table-bordered bordered">
        <thead style="background-color: #041144;color: #fff;text-align: center;">
          <tr>
            <th scope="col" colspan="2">List Of Items</th>
          </tr>
        </thead>
<tbody class="item-table" style="color: #000; font-weight:bold;">
          <tr>
            <td> Shoe Rack </td>
            <td style="width: 30%;"><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> TV </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> TV Trolly </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Tea Poi </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Sofa </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Sofa cum bed </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Dining Table </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Fridge</td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Kitchen Rack </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Crockery </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Washing M/C </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Double Bed</td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Mattress </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Single Bed </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Cooler </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Almari </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Wardrobe </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Clothes </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Dressing Table </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Air Conditioner </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Luggage </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Bags </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> Boxes </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> <span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span> </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
           <tr>
            <td> <span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span> </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
            <tr>
            <td> <span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span> </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
            <tr>
            <td> <span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span> </td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
        </tbody>
      </table>
        </div>
        <div class="col-md-9 col-xs-9">
                <table class="table table-bordered bordered">
        <thead style="background-color: #041144;color: #fff;text-align: center;">
          <tr>
            <th scope="col" width="7%">Sr No.</th>
            <th scope="col">Particulars</th>
            <th scope="col" width="15%">Normal</th>
            <th scope="col" width="15%">Container</th>
          </tr>
        </thead>
        <tbody style="color: #000; font-weight:bold">
          <tr>
            <td> 1.</td>
            <td> Transportation charges </td>
            <td><span><input name="transpotation_charges_n" id="transpotation_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="transpotation_charges_c" id="transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td>2. </td>
            <td> Packing Charges</td>
            <td><span><input name="packing_charges_n" id="packing_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="packing_charges_c" id="packing_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td>3. </td>
            <td> Loading Charges Lift :</td>
            <td><span><input name="loading_charges_n" id="loading_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="loading_charges_c" id="loading_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td>4. </td>
            <td> Unloading Charges Lift : </td>
            <td><span><input name="unloading_charges_n" id="unloading_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="unloading_charges_c" id="unloading_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 5. </td>
            <td> Unpacking Charges </td>
            <td><span><input name="unpacking_charges_n" id="unpacking_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="unpacking_charges_c" id="unpacking_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 6.</td>
            <td> Escort with the vehicle inclusive of Escort’s expenses & return fare </td>
            <td><span><input name="escort_fare_n" id="escort_fare_n" type="text" class="form-control"/></span></td>
            <td><span><input name="escort_fare_c" id="escort_fare_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 7. </td>
            <td> Car transportation Charges</td>
            <td><span><input name="car_transpotation_charges_n" id="car_transpotation_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="car_transpotation_charges_c" id="car_transpotation_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 8. </td>
            <td> Insurance Charges @3% on declaration value of goods </td>
            <td><span><input name="insurance_charges_n" id="insurance_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="insurance_charges_c" id="insurance_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 9. </td>
            <td> Mathadi Kamgar Union Charges by party </td>
            <td><span><input name="mathadi_charges_n" id="mathadi_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="mathadi_charges_c" id="mathadi_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 10. </td>
            <td> Check Post by Party </td>
            <td><span><input name="checkPost_n" id="checkPost_n" type="text" class="form-control"/></span></td>
            <td><span><input name="checkPost_c" id="checkPost_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 11. </td>
            <td> Loading & Unloading Charges at warehouse </td>
            <td><span><input name="warehouse_charges_n" id="warehouse_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="warehouse_charges_c" id="warehouse_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 12. </td>
            <td> Service Charges </td>
            <td><span><input name="service_charges_n" id="service_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="service_charges_c" id="service_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 13. </td>
            <td> Storage Charges </td>
            <td><span><input name="storage_charges_n" id="storage_charges_n" type="text" class="form-control"/></span></td>
            <td><span><input name="storage_charges_c" id="storage_charges_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 14. </td>
            <td> GST.................%</td>
            <td><span><input name="gst_n" id="gst_n" type="text" class="form-control"/></span></td>
            <td><span><input name="gst_c" id="gst_c" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td> 15. </td>
            <td> St. Charges </td>
            <td><span><input name="gst_nn" id="gst_nn" type="text" class="form-control"/></span></td>
            <td><span><input name="gst_cc" id="gst_cc" type="text" class="form-control"/></span></td>
          </tr>
          <tr>
            <td colspan="2" style="background-color: #f34545;"> <b style="color: #fff"> ADVANCE</b> <input type="text" name="advance" style="width: 120px" /> <b style="float: right;color: #fff">TOTAL </b></td>
            <td><span><input name="gst_nn" id="gst_nn" type="text" class="form-control"/></span></td>
            <td><span><input name="gst_cc" id="gst_cc" type="text" class="form-control"/></span></td>
          </tr>               
        </tbody>
      </table>



      <table>
        <tr>
         <span class="mt-3"><b style="color: #2f4ab5;font-size: 14px"> TERMS & CONDITIONS: </b> </span>
         <td class="terms" colspan="2" style="width: 72%;text-align: justify;">
          <span class="mb-1">
          <p> 1. Carrying Liquor, Gas cylinder, Acid, Explosives, any type of inflammable liquids and illegal articles are totally prohibited. </p>
          <p> 2. Minimum 10 Liters fuel should be available in the car carrier point and same way from car carrier point to the destination.</p>
          <p> 3. We do not undertake electrical, Carpentry & Plumbing job. We will provide on the basis of availability and will be charged extra.</p>
          <p> 4. If requires we also provide STORAGE FACILITY to our customers at very nominal Charges of Rs. ............... per day. But Loading, Unloading and
          local delivery charges will be charged extra. After local shifting Packing materials will be taken bak on the same day. </p>
          <p> 5. After local shifting Packing materials will be taken back on the same day. </p>
          <p> 6. If there is any extra service or packing of any article other than our Article List/Estimate, we charge extra for the same accordingly. </p>
          <p> 7. We request you to give us 3 days advance notice to give you a prompt service. We request you to pay us 25% as advance on total amount along
          with purchase order and balance amount on completion of your work at loading point. </p>
          <p> 8. If you send back our packers who came for packing asper our discussion, you have to pay all the expenses incurred. </p>
          <p>  9. All Payment should be made in fovour of <b style="color: #071446;"> M/s. Vishwashri Packers & Movers </b> only. </p>
          <p> 10. We or our Agent shall be exempted from any kind of loss or damage done due to accident, pilferage, fire, rain, collution, or any other road / raider hazard or any natural
          calamity. so to avoid loss or damage. We advise you to insure your consignment covering all risk. No individual policy/Receipt will be given in case or carrier risk. </p>
          <p>  11. Please do the following things in advance berore the commencement of packing to avoid wastage of time, we are not responsible for breakage of pots
          Switch off the refrigerator 12 hours befor packing, jewellery / Ornaments / Document and small valuable items should be removed before packing.</p>
          <p> 12. for monsoon, rainy seson, foggy weather, riots, vehicle breakdown and any other natural calamity, please add tow days extra in transit time. </p>
        </span>
        </td>
        <td style="text-align:right;"> <br><br><br><br><img src="sign.png" style="height: 120px;margin-top: -22px;margin-right: 35px;"><br><b style="color: #071446;padding-left: 10px;font-size: 12px;">For Vishwashri Packers & Movers</b></td>
      </tr>
    </table>
        </div>
      </div>

    <table class="table bt" style="text-align:center;">         
     <tr style="font-size: 12px;font-weight: 800;">
       <td>  <br>Client’s Signature </td>
       <td style="color: red">“Please keep your Cash/Jewelry in your Custody / Lock’ </td>
       <td><u>All Subject to Pune Jurisdiction </u></td>
     </tr>
     <tr style="border:1px solid; background-image: linear-gradient(#080778, red);color: #fff;font-style: italic;">
       <td colspan="3">
         <h2 style="text-align: center;margin: 0px 0px;font-family: auto;font-weight: 900"> Best Logistics Solution All Over India </h2>
       </td>
     </tr>
   </table>
 </div>
</div>


<a class="float" target="_blank">
  <button style="background: transparent;border: none;" onclick="myPdf();"> <i class="fa fa-whatsapp my-float" title="Share PDF"></i></button>
</a>
<a class="floats">
 <button style="background: transparent;border: none;" onclick="saveDoc();"><i class="fa fa-file-pdf-o my-float" title="Download PDF"></i></button>   
</a>

</body>
</html>


<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/html2pdf.bundle.js"></script>

<script type="text/javascript">
  function myPdf(){
   var element = document.getElementById('canvas_div_pdf');

   var opt = {

    pagebreak: { mode: 'avoid-all' },

    html2canvas: { scale: 2 },

    jsPDF: { orientation: 'p',
    unit: 'pt',
    format: [950, 900],
    compress: false,
    fontSize: 12,
    lineHeight: 1,
    autoSize: false,
    printHeaders: false } 

  };
  html2pdf().from(element).set(opt).toPdf().output('datauristring').then(function (pdfAsString) {
    var arr = pdfAsString.split(',');
    pdfAsString= arr[1];    

    var data = new FormData();
    data.append("data" , pdfAsString);
    var xhr = new XMLHttpRequest();    
        xhr.open( 'post', 'Createpdf.php', true ); //Post the Data URI to php Script to save to server
        xhr.send(data);
        xhr.onreadystatechange = function() {
          if (xhr.readyState == XMLHttpRequest.DONE) {
            $('#myModal').modal('show');
            console.log(xhr.responseText);
            sessionStorage.setItem("file_name",xhr.responseText); 
            var pdf=sessionStorage.getItem("file_name"); 
            var ifrm = document.createElement("iframe");
            ifrm.setAttribute("src", "pdf/" + pdf);
            ifrm.style.width = "400px";
            ifrm.style.height = "200px";
            ifrm.setAttribute("id","path")
            $("#msessage").append(ifrm);

            // Create anchor element.
            var a = document.createElement('a'); 

                // Create the text node for anchor element.
                var link = document.createTextNode("Download Your Quotation ");

                // Append the text node to anchor element.
                a.appendChild(link); 

                // Set the title.
                a.title = "Download Your Quotation "; 

                // Set the href property.
                a.onclick = saveDoc; 

                // Append the anchor element to the body.
                document.getElementById("anchor").prepend(a); 

                document.getElementById("pdf_text").value="pdf/" + pdf;
              }
            }
          })
}

function saveDoc() {

 var element = document.getElementById('canvas_div_pdf');

 var opt = {

  pagebreak: { mode: 'avoid-all' },

  html2canvas: { scale: 2},

  jsPDF: { orientation: 'p',
  unit: 'pt',
  format: [950, 900],
  compress: false,
  fontSize: 12,
  lineHeight: 1,
  autoSize: false,
  printHeaders: false } 

};
html2pdf().from(element).set(opt).toPdf().save('quotation.pdf');
}

function redirecturl()

{ 

  var phone_no= document.getElementById("phone_no").value;

  var path = document.getElementById("path").src

  var url = "https://wa.me/91"+phone_no+"?text= Click the link below to download your quotation "+path;
  window.open(url,"_blank");
}

function doMath() {
 var transpotation_charges_n=document.getElementById("transpotation_charges_n").value;
 var transpotation_charges_c=document.getElementById("transpotation_charges_c").value;
 var packing_charges_n=document.getElementById("packing_charges_n").value;
 var packing_charges_c=document.getElementById("packing_charges_c").value;
 var loading_charges_n=document.getElementById("loading_charges_n").value;
 var loading_charges_c=document.getElementById("loading_charges_c").value;
 var unloading_charges_n=document.getElementById("unloading_charges_n").value;
 var unloading_charges_c=document.getElementById("unloading_charges_c").value;
 var unpacking_charges_n=document.getElementById("unpacking_charges_n").value;
 var unpacking_charges_c=document.getElementById("unpacking_charges_c").value;
 var escort_fare_n=document.getElementById("escort_fare_n").value;
 var escort_fare_c=document.getElementById("escort_fare_c").value;
 var car_transpotation_charges_n=document.getElementById("car_transpotation_charges_n").value;
 var car_transpotation_charges_c=document.getElementById("car_transpotation_charges_c").value;
 var insurance_charges_n=document.getElementById("insurance_charges_n").value;
 var insurance_charges_c=document.getElementById("insurance_charges_c").value;
 var mathadi_charges_n=document.getElementById("mathadi_charges_n").value;
 var mathadi_charges_c=document.getElementById("mathadi_charges_c").value;
 var checkPost_n=document.getElementById("checkPost_n").value;
 var checkPost_c=document.getElementById("checkPost_c").value;
 var warehouse_charges_n=document.getElementById("warehouse_charges_n").value;
 var warehouse_charges_c=document.getElementById("warehouse_charges_c").value;
 var service_charges_n=document.getElementById("service_charges_n").value;
 var service_charges_c=document.getElementById("service_charges_c").value;
 var storage_charges_n=document.getElementById("storage_charges_n").value;
 var storage_charges_c=document.getElementById("storage_charges_c").value;
 var gst_n=document.getElementById("gst_n").value;
 var gst_c=document.getElementById("gst_c").value;

 var total_c= parseInt(transpotation_charges_c) + parseInt(packing_charges_c) + parseInt(loading_charges_c) + parseInt(unloading_charges_c) + parseInt(unpacking_charges_c) + parseInt(escort_fare_c) + parseInt(car_transpotation_charges_c) + parseInt(insurance_charges_c) + parseInt(mathadi_charges_c) + parseInt(checkPost_c) + parseInt(warehouse_charges_c) + parseInt(service_charges_c) + parseInt(storage_charges_c) +parseInt(gst_c) + 350 ;

 var total_n = parseInt(transpotation_charges_n) + parseInt(packing_charges_n) + parseInt(loading_charges_n) + parseInt(unloading_charges_n) + parseInt(unpacking_charges_n) + parseInt(escort_fare_n) + parseInt(car_transpotation_charges_n) + parseInt(insurance_charges_n) + parseInt(mathadi_charges_n) + parseInt(checkPost_n) + parseInt(warehouse_charges_n) + parseInt(service_charges_n) + parseInt(storage_charges_n) + parseInt(gst_n) + 350; 

 document.getElementById("total_c").value = total_c;
 document.getElementById("total_n").value = total_n;
}
</script>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">Send your quotation</h4>

        </div>
        <div class="modal-body">
         <div class="form-group">
          <label for="phone">Phone No</label>
          <input type="text"  id="phone_no" name="phone_no" placeholder="Enter recipient mobile" style="width: 350px">

        </div>
        <br>
        <div class="form-group">
          <label for="phone"> PDF</label>
          <br>
          <span id="msessage"></span>
        </div>
        <input type="hidden" name="pdf_text" id="pdf_text" class="form-control">
        <span id="anchor"></span>
      </div>
      <div class="modal-footer">             
        <a onClick="redirecturl()" target="_blank"><button type="button" name="submit" class="btn btn-danger">Share</button></a>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
</div>
</div>
